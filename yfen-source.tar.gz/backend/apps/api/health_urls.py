from django.urls import path
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

class HealthView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    def get(self, request):
        return Response({"status": "ok", "service": "yfen-api", "version": "0.1.0"})

urlpatterns = [path("", HealthView.as_view(), name="health")]
